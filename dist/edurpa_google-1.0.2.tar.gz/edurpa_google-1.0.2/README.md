# EduRPA
EduRPA is an robotframework librabry that support feature in education field